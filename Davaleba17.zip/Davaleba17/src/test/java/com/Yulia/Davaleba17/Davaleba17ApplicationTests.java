package com.Yulia.Davaleba17;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Davaleba17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
